# Service Blueprint: [Service Name]

## Scenario: [Describe the service scenario]

### Blueprint Visualization

```mermaid
sequenceDiagram
    participant User
    participant Front-Stage
    participant Back-Stage
    participant Support

    User->>Front-Stage: [User Action]
    Front-Stage->>Back-Stage: [Front-Stage Action]
    Back-Stage->>Support: [Back-Stage Action]
    Support-->>Back-Stage: [Support Process]
    Back-Stage-->>Front-Stage: [Response]
    Front-Stage-->>User: [Response]
```

| Component | Phase 1: [Name] | Phase 2: [Name] | Phase 3: [Name] | Phase 4: [Name] |
|-----------|-----------------|-----------------|-----------------|-----------------|
| **User Actions** | [What the user does] | | | |
| **Front-Stage Actions** | [Visible interactions] | | | |
| **Back-Stage Actions** | [Internal processes] | | | |
| **Support Processes** | [Systems, tools, etc.] | | | |
| **Evidence** | [Physical/digital proof] | | | |

## Critical Success Factors
- [Factor 1]
- [Factor 2]
