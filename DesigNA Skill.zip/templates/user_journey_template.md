# User Journey Map: [Service Name]

## Market Size Estimation

| Metric | Value | Description |
|--------|-------|-------------|
| **TAM** (Total Addressable Market) | [e.g., $10B] | Total market demand for the service. |
| **SAM** (Serviceable Addressable Market) | [e.g., $2B] | The portion of TAM targeted by your products/services. |
| **SOM** (Serviceable Obtainable Market) | [e.g., $500M] | The portion of SAM you can realistically capture. |

### Journey Visualization

```mermaid
journey
    title User Journey Map
    section Discovery
      Research: 5: User
      Comparison: 3: User
    section Engagement
      Onboarding: 4: User
      Usage: 5: User
    section Completion
      Checkout: 4: User
    section Post-Service
      Feedback: 3: User
```

| Phase | Step | User Action | Touchpoint | Emotional State | Pain Points | Opportunities |
|-------|------|-------------|------------|-----------------|-------------|---------------|
| **Discovery** | 1. [Step Name] | [What the user does] | [Website, App, Store, etc.] | [Happy, Frustrated, Neutral] | [What's wrong?] | [How to improve?] |
| | 2. [Step Name] | | | | | |
| **Engagement** | 3. [Step Name] | | | | | |
| | 4. [Step Name] | | | | | |
| **Completion** | 5. [Step Name] | | | | | |
| **Post-Service** | 6. [Step Name] | | | | | |

## Key Insights
- [Insight 1]
- [Insight 2]
