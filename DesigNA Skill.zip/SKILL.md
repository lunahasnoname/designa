---
name: service-design
description: "A comprehensive toolkit for designing user-centric services, covering research, ideation, and journey mapping. Use for: user research, market analysis, brainstorming, user journey mapping, and service blueprinting."
---

# Service Design

## Overview

This skill provides a structured workflow for designing and improving services by focusing on user needs, experiences, and the underlying processes that support them.

## Workflow

### 1. Discovery & Research
Understand the problem space, users, and market context.
- **Task**: Conduct in-depth research using `deep-research` or `market-research-reports`.
- **Output**: Market size estimation (TAM/SAM/SOM), empathy maps, and a summary of key findings.

### 2. Ideation & Brainstorming
Generate and refine creative solutions.
- **Task**: Use the `brainstorming` skill to explore ideas and potential service concepts.
- **Output**: A prioritized list of ideas and initial service concepts.

### 3. User Journey Mapping
Visualize the end-to-end user experience.
- **Task**: Map out the user's steps, touchpoints, and emotional state throughout the service using Mermaid.js for visualization.
- **Output**: A detailed User Journey Map (use `templates/user_journey_template.md`).

### 4. Service Blueprinting
Detail the service delivery process, including front-stage and back-stage actions using Mermaid.js for visualization.
- **Task**: Create a blueprint that connects user actions to the organizational processes that support them.
- **Output**: A Service Blueprint (use `templates/service_blueprint_template.md`).

### 5. UX Audit & Competitor Analysis
- **Task**: Evaluate the user experience using the Kano Model and conduct heuristic evaluation of competitors.
- **Output**: A UX audit bubble chart and a competitor radar chart (use `templates/ux_audit_bubble_chart_template.md` and `templates/competitor_analysis_template.md`).

### 6. Business Model & Synthesis
- **Task**: Define the business model and consolidate all findings into a final specification.
- **Output**: A business model canvas (use `templates/business_model_canvas_template.md`) and a comprehensive Service Design Specification.

## Resources

- `templates/user_journey_template.md`: A markdown template for creating user journey maps with market size estimation and Mermaid.js visualization.
- `templates/service_blueprint_template.md`: A markdown template for creating service blueprints with Mermaid.js visualization.
- `templates/ux_audit_bubble_chart_template.md`: A template for a UX audit bubble chart based on the Kano Model.
- `templates/competitor_analysis_template.md`: A template for competitor analysis with a heuristic evaluation radar chart.
- `templates/business_model_canvas_template.md`: A template for creating a business model canvas.
- `references/design_principles.md`: A guide to core service design principles.
