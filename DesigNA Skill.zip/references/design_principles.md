# Core Service Design Principles

1. **User-Centric**: Services should be designed based on a deep understanding of user needs, behaviors, and experiences.
2. **Co-Creative**: Involve all stakeholders (users, providers, partners) in the design process.
3. **Sequencing**: Services should be visualized as a sequence of interrelated actions and touchpoints.
4. **Evidencing**: Intangible services should be made tangible through physical or digital evidence.
5. **Holistic**: Consider the entire environment and context in which the service is delivered.

## Key Frameworks
- **Double Diamond**: Discover, Define, Develop, Deliver.
- **Service Blueprinting**: Mapping the front-stage and back-stage of service delivery.
- **User Journey Mapping**: Visualizing the end-to-end user experience.
